#!/bin/bash
source .common

check_docker
_stop