#!/bin/bash

docker build -t finals_web_intro .
