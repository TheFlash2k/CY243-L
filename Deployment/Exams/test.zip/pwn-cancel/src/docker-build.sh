#!/bin/bash

docker build -t final_pwn_cancel:latest .
